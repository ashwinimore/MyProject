package config;

public class AppConfig {

	public AppConfig() {
		// TODO Auto-generated constructor stub
	}

}
